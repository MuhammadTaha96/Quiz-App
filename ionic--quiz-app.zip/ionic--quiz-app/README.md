# ionic3-kids-quiz

Original code from https://www.joshmorony.com/create-a-data-driven-quiz-app-in-ionic-2-part-1/

